</div> <!-- Close content div -->
<footer>
    <p>&copy; 2024 Fitness Tracker</p>
</footer>
</div> <!-- Close container div -->
</body>
</html>

